import { createApp } from 'vue'
import App from './App.vue'

import '../css/app.css'
import 'bootstrap'

createApp(App).mount('#app')