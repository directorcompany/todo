<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>To-Do App</title>
    @vite(['resources/css/app.css', 'resources/js/main.js'])
</head>
<body class="bg-light">
    <div id="app"></div>
</body>
</html>